const openWe2atherKey = "eeabe7543b843d62469b9a1ce3953532";

// export {openWeatherKey};