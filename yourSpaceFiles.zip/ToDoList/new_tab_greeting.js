{/* <script type="module">
import { openWeatherKey } from "./openWeatherAPIKey";
</script> */}

//greeting creation
var greetings = [
    "Ready to tackle the day? Give it your all! 💪", "Hello, hope you are well. 😊", "Good Morning! 🌞", "Good Afternoon! Ready for Lunch? 🍔", "If you feel overwhelmed, remember to relax for while, and come back stronger!", "Remember to relax from eyes from the computer screen every so often. Your eyes will thank you!"
];
var early_morning_greetings = [
    "Ready to tackle the day? Give it your all! 💪", "Good Morning! Hope you're well rested.🌞", "Remember to stay hydrated and eat well. Be sure to have your breakfast! 🥞", "Remember, every morning is a beautiful morning.", "Seize every moment of the day. Be limitless.", "“Some people dream of success, while other people get up every morning and make it happen.” – Wayne Huizenga 💼", "“If you get up in the morning and think the future is going to be better, it is a bright day. Otherwise, it’s not.” – Elon Musk 🚗","“Morning comes whether you set the alarm or not.” – Ursula K. Le Guin 📚"
];
var morning_greetings = [
    "Ready to tackle the day? Give it your all! 💪", "Be sure to get in some physical activity today. Even a walk is ok!", "\"I've failed over and over and over again in my life. And that is why I succeed.\" - Michael Jordan 🏀", "Be ambitious and seize every moment.", "Remember, if you ever feel overwhelmed...take a step back, recollect, and come back stronger!", "“In these times you have to be an optimist to open your eyes when you awake in the morning.” – Carl Sandburg 📃", "“When everything seems to be going against you, remember that the airplane takes off against the wind, not with it.” – Henry Ford 🚗", "“It does not matter how slowly you go as long as you do not stop.” – Confucius ☯"
];
var early_afternoon_greetings = [
    "\"The secret to getting ahead is getting stared\" - Mark Twain", "Be calm, you got this. 💪", "Remember to give your eyes some rest from your computer screen. They'll thank you later!", "Feeling like you can't stay concentrated? Try our \"Productivity Mode\" to block out unimportant websites.", "Good Afternoon! Ready for Lunch? 🍔", "“The greatest glory in living lies not in never falling, but in rising every time we fall.” — Nelson Mandela 🕊", "“Spread love everywhere you go. Let no one ever come to you without leaving happier.” — Mother Teresa ☮", "“If life were predictable it would cease to be life, and be without flavor.” — Eleanor Roosevelt"
];
var late_afternoon_greetings = [
    "It always seems impossible until it's done. 🎯", "\"Belive you can and you're halfway there.\" - Theodore Roosevelt", "Loosing motivation? Take a step back, and think about why you began your journey in the first place.", "\"You are never too old to set another goal or to dream a new dream\" - C.S. Lewis", "Be sure to get some physical activity today. Your body will thank you! 🏋️", "“In the end, it’s not the years in your life that count. It’s the life in your years.” — Abraham Lincoln 🎩", " “You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose.” — Dr. Seuss", "“The real test is not whether you avoid this failure, because you won’t. It’s whether you let it harden or shame you into inaction, or whether you learn from it; whether you choose to persevere.” — Barack Obama"
];
var evening_greetings = [
    "Good evening. Are you excited for dinner? 😋", "Be sure to drink water throughout the day. Stay hydrated! 💧", "Take a break from your work if you're tired. Your well being is more important than anything else!", "Always try to expand your skillset. You can never be too old to learn! 📚", "Feeling like you can't stay concentrated? Try our \"Productivity Mode\" to block out unimportant websites.", "“A day without laughter is a day wasted.” – Charlie Chaplin 🎭", "“Someday is not a day of the week.” – Denise Brennan-Nelson 📔", "“Don’t judge each day by the harvest you reap but by the seeds that you plant.” – Robert Louis Stevenson 📖"
];
var night_greetings = [
    "It's now getting late in the day. Be sure to have a snack before bed!", "\"The best preparation for tomorrow is doing your best today.\" - Harriett Jackson Brown Jr 📖", "Before bed, be sure to reflect on ways you could've improved your day. This can be productivity wise, or through your physical and mental well-being all day.", "Tip: Plan out tommorow the day before, it'll allow you to gain a clearer focus on your future goals. Use the \"todo list\" section of the app to do so!", "Be sure to relax, and be thankful for today. Tommorow will be just as good! (If not better!)", "“Don’t judge each day by the harvest you reap but by the seeds that you plant.” – Robert Louis Stevenson 📖", "“Being defeated is often a temporary condition. Giving up is what makes it permanent.” – Marilyn Vos Savant", "“Your future depends on your dreams, so go to sleep.”  – Mesut Barazany"
];
var used_greeting = "";

document.addEventListener("DOMContentLoaded", function(){
    var wow = new Date();
    var time = wow.getHours();
    if (time <= 8){
        var number = Math.floor(Math.random() * 8);
        used_greeting = early_morning_greetings[number];
    }
    else if (time === 9 || time === 10 || time === 11){
        var number = Math.floor(Math.random() * 8);
        used_greeting = morning_greetings[number];
    }
    else if (time === 12 || time === 13 || time === 14){
        var number = Math.floor(Math.random() * 8);
        used_greeting = early_afternoon_greetings[number];
    }
    else if (time === 15 || time === 16){
        var number = Math.floor(Math.random() * 8);
        used_greeting = late_afternoon_greetings[number];
    }
    else if (time === 17 || time === 18 || time === 19 || time === 20){
        var number = Math.floor(Math.random() * 8);
        used_greeting = evening_greetings[number];
    }
    else{
        var number = Math.floor(Math.random() * 8);
        used_greeting = night_greetings[number];
    }; 
    document.getElementById("new-tab-greeting").innerHTML = used_greeting;
});

//clock creation
function clock () {
    let full_time = new Date();
    let hour = full_time.getHours();
    let minutes = full_time.getMinutes();
    let seconds = full_time.getSeconds();
    let period = "AM";
    if (hour == 0){
        hour = 12;
    }
    else if (hour >= 12){
        hour = hour - 12;
        period = "PM";
    }
    hour = hour < 10 ? "0" + hour : hour;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;
    
    let final_time = `${hour}:${minutes}:${seconds} ${period}`;
    setInterval(clock, 1000);
    document.getElementById("new-tab-time").innerHTML = final_time;
}
clock();

//Changing image background creation
var usable_mountain_photos = ["url('./newtab_images/mountain_images/voros_mountain.jpg')", "url('./newtab_images/mountain_images/zhang_mountain.jpg')", "url('./newtab_images/mountain_images/earle_mountain.jpg')", "url('./newtab_images/mountain_images/tandon_mountain.jpg')", "url('./newtab_images/mountain_images/emsley_mountain.jpg')","url('./newtab_images/mountain_images/zindel_mountain.jpg')","url('./newtab_images/mountain_images/kleine_mountain.jpg')", "url('./newtab_images/mountain_images/olivares_mountain.jpg')"];
var mountain_photo_credits = ["Photo by: Benjamin Voros, https://unsplash.com/@vorosbenisop", "Photo by: Jerry Zhang, https://unsplash.com/@z734923105", "Photo by: Joshua Earle, https://unsplash.com/@joshuaearle", "Photo by: Rohit Tandon, https://unsplash.com/@rohittandon", "Photo by: Kalen Emsley, https://unsplash.com/@kalenemsley", "Photo by: Bailey Zindel, https://unsplash.com/@baileyzindel", "Photo by: Konstantin Klein, https://unsplash.com/@konstantinkleine", "Photo by: Mattieu Olivares, https://unsplash.com/@techntravel_"];

var gradient_photos = ["url('./newtab_images/gradient_images/gradientOne.jpg')", "url('./newtab_images/gradient_images/gradientTwo.jpg')", "url('./newtab_images/gradient_images/gradientThree.jpg')", "url('./newtab_images/gradient_images/gradientFour.jpg')", "url('./newtab_images/gradient_images/gradientFive.jpg')", "url('./newtab_images/gradient_images/gradient6ix.jpg')", "url('./newtab_images/gradient_images/gradientSeven.jpg')", "url('./newtab_images/gradient_images/gradientEight.jpg')"];
var gradient_credits = ["Photo by: Gradienta, https://unsplash.com/@gradienta","Photo by: Luke Chesser, https://unsplash.com/@lukechesser", "Photo by: Luke Chesser, https://unsplash.com/@lukechesser", "Photo by: Gradienta, https://unsplash.com/@gradienta", "Photo by: Cesar Couto, https://unsplash.com/@xcrap", "Photo by: Luke Chesser, https://unsplash.com/@lukechesser", "Photo by: Luke Chesser, https://unsplash.com/@lukechesser", "Photo by: Gradienta, https://unsplash.com/@gradienta"];

var dark_photos = ["url('./newtab_images/dark_images/darkOne.jpg')","url('./newtab_images/dark_images/darkTwo.jpg')","url('./newtab_images/dark_images/darkThree.jpg')", "url('./newtab_images/dark_images/darkFour.jpg')", "url('./newtab_images/dark_images/darkFive.jpg')", "url('./newtab_images/dark_images/darkSix.jpg')", "url('./newtab_images/dark_images/darkSeven.jpg')", "url('./newtab_images/dark_images/darkEight.jpg')" ];
var dark_credits = ["Photo by: Elliott Engelmann, https://unsplash.com/@elliottengelmann","Photo by: Joshua Earle, https://unsplash.com/@joshuaearle", "Photo by: Noah Silliman, https://unsplash.com/@noahsilliman", "Photo by: Andrew Schultz, https://unsplash.com/@andrewschultz", "Photo by: Breno Machado, https://unsplash.com/@brenomachado", "Photo by: Jonatan Pie, https://unsplash.com/@r3dmax", "Photo by: Clay Banks, https://unsplash.com/@claybanks", "Photo by: Osman Rana, https://unsplash.com/@osmanrana"];

var wildlife_photos = ["url('./newtab_images/wildlife_images/wildlifeOne.jpg')","url('./newtab_images/wildlife_images/wildlifeTwo.jpg')", "url('./newtab_images/wildlife_images/wildlifeThree.jpg')", "url('./newtab_images/wildlife_images/wildlifeFour.jpg')", "url('./newtab_images/wildlife_images/wildlifeFive.jpg')", "url('./newtab_images/wildlife_images/wildlifeSix.jpg')", "url('./newtab_images/wildlife_images/wildlifeSeven.jpg')", "url('./newtab_images/wildlife_images/wildlifeEight.jpg')"];
var wildlife_credits = ["Photo by: Zdeněk Macháček, https://unsplash.com/@zmachacek","Photo by: Kelly Sikkema, https://unsplash.com/@kellysikkema", "Photo by: Vincent van Zalinge, https://unsplash.com/@vincentvanzalinge", "Photo by: Diana Parkhouse, https://unsplash.com/@ditakesphotos", "Photo by: Nam Anh, https://unsplash.com/@bepnamanh", "Photo by: Justin DoCanto, https://unsplash.com/@justindocanto", "Photo by: Kris Mikael Krister, https://unsplash.com/@kmkr", "Photo by: Zdeněk Macháček, https://unsplash.com/@zmachacek"];

function refreshPage(){
    window.location.reload();
} 

document.body.style.backgroundImage = localStorage.getItem("bbg");
// document.body.style.backgroundRepeat = "no-repeat";
// document.body.style.backgroundSize = "cover";
document.body.style.backgroundImage.width = "100%";
document.body.style.backgroundImage.position = "absolute";
// document.body.style.backgroundImage.backgroundRepeat = "no-repeat";
document.body.style.height = "100%";


var selectedBackground;
var background;
var credits;
var color = "black";

function background(){
    selectedBackground = document.getElementById("select_greeting_screen").value;
    localStorage.setItem("ddvalue", selectedBackground);
    return true;
}

document.addEventListener('DOMContentLoaded', function() {
document.getElementById("photo-credits").innerHTML = localStorage.getItem("credit");
document.getElementById("new-tab-greeting").style.color = localStorage.getItem("color");
document.getElementById("new-tab-greeting").style.backgroundColor = localStorage.getItem("backgroundColor");
document.getElementById("new-tab-time").style.backgroundColor = localStorage.getItem("backgroundColor");
document.getElementById("photo-credits").style.backgroundColor = localStorage.getItem("backgroundColor");
document.getElementById("new-tab-time").style.color = localStorage.getItem("color");
document.getElementById("weather").style.color = localStorage.getItem("color");
document.getElementById("weatherStatus").style.color = localStorage.getItem("color");
document.getElementById("photo-credits").style.color = localStorage.getItem("color");
document.getElementById("background_submit").addEventListener("click", background);
document.getElementById("background_submit").addEventListener("click", refreshPage);
document.getElementById("background_submit").addEventListener("click", function(){
    if (localStorage.getItem("ddvalue") === "Google Home Screen"){
        window.location.href = "http://www.google.com";
    } else if (localStorage.getItem("ddvalue") === "Mountain Set"){
        var number = Math.floor(Math.random() * 8);
        background = document.body.style.backgroundImage = usable_mountain_photos[number];
        credits = mountain_photo_credits[number];
        localStorage.setItem("credit", credits);
        localStorage.setItem("bbg", background);
        if (number === 0){
            color = "white";
            localStorage.setItem("color", color);
            backgroundColor = "rgba(0,0,0,0.5)";
            localStorage.setItem("backgroundColor", backgroundColor);
        } else{
            color = "black";
            localStorage.setItem("color", color);
            backgroundColor = "rgba(128, 128, 128, 0.5)";
            localStorage.setItem("backgroundColor", backgroundColor);
        }
    } else if (localStorage.getItem("ddvalue") === "Wildlife Set"){
        var number = Math.floor(Math.random() * 8);
        background = document.body.style.backgroundImage = wildlife_photos[number];
        credits = wildlife_credits[number];
        localStorage.setItem("credit", credits);
        localStorage.setItem("bbg", background);
        if (number === 0 || number === 1){
            color = "white";
            backgroundColor = "rgba(0,0,0,0.5)";
            localStorage.setItem("backgroundColor", backgroundColor);
            localStorage.setItem("color", color);
        } else{
            color = "black";
            backgroundColor = "rgba(128, 128, 128, 0.5)";
            localStorage.setItem("backgroundColor", backgroundColor);
            localStorage.setItem("color", color);
        }
    } else if (localStorage.getItem("ddvalue") === "Solid Color Set"){
        var number = Math.floor(Math.random() * 8);
        background = document.body.style.backgroundImage = gradient_photos[number];
        credits = gradient_credits[number];
        localStorage.setItem("credit", credits);
        localStorage.setItem("bbg", background);
        if (number === 1 || number === 5 || number === 7){
            color = "white";
            localStorage.setItem("color", color);
            backgroundColor = "rgba(0,0,0,0.5)";
            localStorage.setItem("backgroundColor", backgroundColor);
        } else{
            color = "black";
            localStorage.setItem("color", color);
            backgroundColor = "rgba(128, 128, 128, 0.5)";
            localStorage.setItem("backgroundColor", backgroundColor);
        }
    } else if(localStorage.getItem("ddvalue") === "Dark Set"){
        var number = Math.floor(Math.random() * 8);
        background = document.body.style.backgroundImage = dark_photos[number];
        credits = dark_credits[number];
        localStorage.setItem("credit", credits);
        localStorage.setItem("bbg", background);
        color = "white";
        localStorage.setItem("color", color);
        backgroundColor = "rgba(0,0,0,0.5)";
        localStorage.setItem("backgroundColor", backgroundColor);
    }
});
});

//find my location function
// document.querySelector('#findWeather').addEventListener('click', geoLookUp, false)
window.addEventListener('load', geoLookUp, false)

function geoLookUp(){
    const status = document.querySelector('#weatherStatus')

    function success(position){
        const latitude = position.coords.latitude
        const longitude = position.coords.longitude
        status.textContent = `lat: ${latitude}, lon: ${longitude}`
        setWeather(latitude, longitude)
    }
    function error(err){
        status.textContent = `Unable to retrieve location. Error: ${err.code}. ${err.message}`
    }

    if(!navigator.geolocation){
        status.textContent = "Geolocation isn't allowed by your browser. Please switch to another browser, such as Chrome, to use this function."
    } else{
        status.textContent = "Locating..."
        navigator.geolocation.getCurrentPosition(success, error)
    }
}

//weather function
function setWeather(latitude, longitude){
    const p = document.querySelector('#weather p');
    const openWeatherKey = "eeabe7543b843d62469b9a1ce3953532";
    
    let openWeatherData = {};
    let xhr = new XMLHttpRequest();
    xhr.open('GET', `http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${openWeatherKey}&units=metric`)
    xhr.responseType = 'text'
    
    xhr.addEventListener('load', function(){
        if(xhr.status === 200){
            p.textContent = "loading..."
            openWeatherData = JSON.parse(xhr.responseText)
            populateWeatherInfo(openWeatherData, p)
        } else{
            p.textContent = "error: " + xhr.status
        }
    }, false )
    
    xhr.send()
}

function populateWeatherInfo(openWeatherData, p){
    //name, tempurature, wind speed
    const location = openWeatherData.name
    const tempurature = Math.round(openWeatherData.main.temp)
    const wind = Math.round(openWeatherData.wind.speed)
    const humidity = openWeatherData.main.humidity
    const description = openWeatherData.weather[0].description
    const image = openWeatherData.weather[0].icon

    // let wind_logo = "./newtab_images/windOne.png"

    // if (localStorage.getItem("color") === "white"){
    //     wind_logo = "./newtab_images/windTwo.png"
    // }
    // <img src="${wind_logo}">
    
    const str = `${location} <br>${tempurature}°C  <br>Wind Speed: ${wind}kph  <br>Humidity: ${humidity}% <br>${description}`
    p.innerHTML = str;

    var iconurl = "http://openweathermap.org/img/wn/" + image + "@2x.png";
    document.getElementById('wicon').src = iconurl
}