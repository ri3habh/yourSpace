//dark theme applyer
function applyTheme(theme){
    document.body.classList.remove("theme-auto", "theme-light", "theme-dark");
    document.body.classList.add(`theme-${theme}`);
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("theme") || "auto";
  
    applyTheme(savedTheme);
  
    for(const optionElement of document.querySelectorAll("#selTheme option")){
        optionElement.selected = savedTheme === optionElement.value;
    }
  
});

//self-meditation guide
const container = document.querySelector('.self-meditation-container');
const text = document.querySelector('#meditation-text');

const totalTime = 7500;
const breatheTime = (totalTime / 5) * 2;
const holdTime = totalTime/5

breatheAnimation()

function breatheAnimation(){
    text.innerHTML = 'Breath In!';
    container.className = 'container grow';

    setTimeout(() => {
        text.innerText = 'Hold';

        setTimeout(() => {
            text.innerText = 'Breathe Out!'
            container.className = 'container shrink'
        }, holdTime)
    }, breatheTime)
}

setInterval(breatheAnimation, totalTime)